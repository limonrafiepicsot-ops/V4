লিমন রেফ্রিজারেটর APK v2.0

নতুন সুবিধা:
- Customer edit
- মাসভিত্তিক ভাড়া আদায় + টাকার পরিমাণ + তারিখ
- বকেয়া ও মোট আদায়ের হিসাব
- WhatsApp রসিদ মেসেজ
- Print receipt / report
- JSON backup/restore
- CSV export
- Customer search/filter
- PIN পরিবর্তন
- পুরোনো v2 ডাটার automatic migration চেষ্টা

GitHub Actions থেকে APK build করা যাবে।
Workflow: Build Limon Refrigerator APK
Artifact: limon-refrigerator-apk-v2
